# Cinésuivi

Application Android de découverte et de suivi de films, avec un focus fort sur :
- Films **français**
- Films **africains**
- Films **anglophones en VF / VOSTFR**

## Stack technique

- **Kotlin** + **Jetpack Compose**
- **MVVM** + Clean Architecture
- **Hilt** (injection de dépendances)
- **Retrofit** + TMDB API
- **Room** (listes personnelles)
- **Coil** pour les images
- **Firebase Auth** + **Play Billing** (prévu)

## Structure du projet

```
app/src/main/java/com/cinesuivi/
├── di/                  # Modules Hilt
├── data/
│   ├── model/           # Modèles de domaine
│   ├── remote/          # API TMDB + Repository
│   └── local/           # Room (listes À voir / Vus / Favoris)
├── domain/
│   └── repository/      # Interfaces
├── ui/
│   ├── theme/
│   ├── navigation/
│   ├── screens/
│   │   ├── home/
│   │   ├── detail/
│   │   ├── lists/
│   │   └── profile/
│   └── components/
└── util/
```

## Configuration requise

1. **Clé API TMDB** (gratuite) :
   - Créez un compte sur https://www.themoviedb.org
   - Allez dans Settings → API → Create
   - Remplacez `VOTRE_CLE_TMDB_ICI` dans :
     - `app/src/main/java/com/cinesuivi/util/Constants.kt`

2. **Android Studio** Hedgehog ou plus récent
3. **JDK 17**

## Lancer le projet

1. Ouvrez le dossier `Cinesuivi` dans Android Studio
2. Laissez Gradle synchroniser
3. Remplacez la clé TMDB
4. Lancez sur un émulateur ou un appareil (API 26+)

## Fonctionnalités actuelles (MVP)

- [x] Structure complète du projet
- [x] Thème sombre/clair style Netflix
- [x] Écran Accueil avec 3 sections prioritaires
- [x] Navigation bottom bar
- [x] Appels API TMDB (Films FR / Afrique / VF)
- [x] Cards films avec affiches
- [x] **Écran Détail film** (backdrop, synopsis, boutons À voir / Déjà vu / Favoris)
- [x] **Listes personnelles** (À voir / Déjà vu / Favoris) avec Room + onglets animés
- [x] **Profil + Abonnements** (mensuel 2,99 € / annuel 24,99 €)
- [x] Animations (fade, slide, AnimatedContent)
- [ ] Écran Recherche
- [ ] Onboarding
- [ ] Mode hors-ligne avancé
- [ ] Recommandations Premium
- [ ] Google Play Billing réel

## Prochaines étapes recommandées

1. Ajouter la vraie clé TMDB
2. Implémenter l’écran Recherche
3. Intégrer Google Play Billing pour les vrais paiements
4. Ajouter l’onboarding
5. Recommandations personnalisées

## Licence

Projet privé – tous droits réservés.
