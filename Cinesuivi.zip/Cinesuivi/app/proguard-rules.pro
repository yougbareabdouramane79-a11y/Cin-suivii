# Add project specific ProGuard rules here.
-keepattributes *Annotation*
-keep class com.cinesuivi.data.remote.dto.** { *; }
-keep class com.cinesuivi.data.model.** { *; }
