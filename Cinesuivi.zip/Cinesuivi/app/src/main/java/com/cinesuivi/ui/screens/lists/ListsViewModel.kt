package com.cinesuivi.ui.screens.lists

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cinesuivi.data.local.UserMovieRepository
import com.cinesuivi.data.local.database.entities.UserMovieEntity
import com.cinesuivi.data.model.Movie
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

data class ListsUiState(
    val toWatch: List<Movie> = emptyList(),
    val watched: List<Movie> = emptyList(),
    val favorites: List<Movie> = emptyList()
)

@HiltViewModel
class ListsViewModel @Inject constructor(
    private val userMovieRepository: UserMovieRepository
) : ViewModel() {

    val uiState: StateFlow<ListsUiState> = combine(
        userMovieRepository.getToWatch(),
        userMovieRepository.getWatched(),
        userMovieRepository.getFavorites()
    ) { toWatch, watched, favorites ->
        ListsUiState(
            toWatch = toWatch.map { userMovieRepository.toMovie(it) },
            watched = watched.map { userMovieRepository.toMovie(it) },
            favorites = favorites.map { userMovieRepository.toMovie(it) }
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ListsUiState()
    )
}
