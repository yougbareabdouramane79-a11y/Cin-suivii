package com.cinesuivi.ui.screens.detail

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cinesuivi.data.local.UserMovieRepository
import com.cinesuivi.data.local.database.entities.UserMovieEntity
import com.cinesuivi.data.model.MovieDetail
import com.cinesuivi.domain.repository.MovieRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DetailUiState(
    val movie: MovieDetail? = null,
    val userStatus: UserMovieEntity? = null,
    val isLoading: Boolean = false,
    val error: String? = null
)

@HiltViewModel
class DetailViewModel @Inject constructor(
    private val movieRepository: MovieRepository,
    private val userMovieRepository: UserMovieRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val movieId: Int = checkNotNull(savedStateHandle["movieId"])

    private val _uiState = MutableStateFlow(DetailUiState())
    val uiState: StateFlow<DetailUiState> = _uiState.asStateFlow()

    init {
        loadMovie()
        observeUserStatus()
    }

    private fun loadMovie() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            movieRepository.getMovieDetail(movieId)
                .onSuccess { detail ->
                    _uiState.update { it.copy(movie = detail, isLoading = false) }
                }
                .onFailure { e ->
                    _uiState.update { it.copy(isLoading = false, error = e.message) }
                }
        }
    }

    private fun observeUserStatus() {
        viewModelScope.launch {
            userMovieRepository.observeMovie(movieId).collect { status ->
                _uiState.update { it.copy(userStatus = status) }
            }
        }
    }

    fun toggleToWatch() {
        val movie = _uiState.value.movie ?: return
        viewModelScope.launch {
            userMovieRepository.toggleToWatch(movie)
        }
    }

    fun toggleWatched() {
        val movie = _uiState.value.movie ?: return
        viewModelScope.launch {
            userMovieRepository.toggleWatched(movie)
        }
    }

    fun toggleFavorite() {
        val movie = _uiState.value.movie ?: return
        viewModelScope.launch {
            userMovieRepository.toggleFavorite(movie)
        }
    }
}
