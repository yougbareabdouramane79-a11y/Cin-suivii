package com.cinesuivi.domain.repository

import com.cinesuivi.data.model.Movie
import com.cinesuivi.data.model.MovieDetail

interface MovieRepository {
    suspend fun getFrenchMovies(page: Int = 1): Result<List<Movie>>
    suspend fun getAfricanMovies(page: Int = 1): Result<List<Movie>>
    suspend fun getVfMovies(page: Int = 1): Result<List<Movie>>
    suspend fun searchMovies(query: String, page: Int = 1): Result<List<Movie>>
    suspend fun getMovieDetail(movieId: Int): Result<MovieDetail>
    suspend fun getPopularMovies(page: Int = 1): Result<List<Movie>>
}
