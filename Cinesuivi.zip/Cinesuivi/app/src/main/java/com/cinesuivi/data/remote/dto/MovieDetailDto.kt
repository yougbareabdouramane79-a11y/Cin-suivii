package com.cinesuivi.data.remote.dto

import com.cinesuivi.data.model.Genre
import com.cinesuivi.data.model.MovieDetail
import com.google.gson.annotations.SerializedName

data class MovieDetailDto(
    val id: Int,
    val title: String,
    @SerializedName("original_title") val originalTitle: String? = null,
    val overview: String? = null,
    @SerializedName("poster_path") val posterPath: String? = null,
    @SerializedName("backdrop_path") val backdropPath: String? = null,
    @SerializedName("release_date") val releaseDate: String? = null,
    val runtime: Int? = null,
    @SerializedName("vote_average") val voteAverage: Double = 0.0,
    @SerializedName("vote_count") val voteCount: Int = 0,
    val genres: List<GenreDto> = emptyList(),
    @SerializedName("original_language") val originalLanguage: String? = null,
    val status: String? = null,
    val tagline: String? = null,
    val budget: Long = 0,
    val revenue: Long = 0,
    val adult: Boolean = false
) {
    fun toDomain(): MovieDetail = MovieDetail(
        id = id,
        title = title,
        originalTitle = originalTitle,
        overview = overview,
        posterPath = posterPath,
        backdropPath = backdropPath,
        releaseDate = releaseDate,
        runtime = runtime,
        voteAverage = voteAverage,
        voteCount = voteCount,
        genres = genres.map { Genre(it.id, it.name) },
        originalLanguage = originalLanguage,
        status = status,
        tagline = tagline,
        budget = budget,
        revenue = revenue,
        adult = adult
    )
}

data class GenreDto(
    val id: Int,
    val name: String
)
