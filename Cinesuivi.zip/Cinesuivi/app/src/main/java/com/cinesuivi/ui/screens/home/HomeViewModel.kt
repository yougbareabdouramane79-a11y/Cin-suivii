package com.cinesuivi.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cinesuivi.data.model.Movie
import com.cinesuivi.domain.repository.MovieRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val frenchMovies: List<Movie> = emptyList(),
    val africanMovies: List<Movie> = emptyList(),
    val vfMovies: List<Movie> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: MovieRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        loadHomeContent()
    }

    fun loadHomeContent() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }

            val french = repository.getFrenchMovies()
            val african = repository.getAfricanMovies()
            val vf = repository.getVfMovies()

            _uiState.update {
                it.copy(
                    frenchMovies = french.getOrElse { emptyList() },
                    africanMovies = african.getOrElse { emptyList() },
                    vfMovies = vf.getOrElse { emptyList() },
                    isLoading = false,
                    error = listOf(french, african, vf)
                        .firstOrNull { r -> r.isFailure }
                        ?.exceptionOrNull()?.message
                )
            }
        }
    }
}
