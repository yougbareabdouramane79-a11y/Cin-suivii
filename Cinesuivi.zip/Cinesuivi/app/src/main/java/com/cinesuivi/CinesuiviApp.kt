package com.cinesuivi

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class CinesuiviApp : Application()
