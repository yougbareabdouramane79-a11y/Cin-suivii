package com.cinesuivi.data.remote.api

import com.cinesuivi.data.remote.dto.MovieResponseDto
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface TmdbApi {

    // Films populaires en français
    @GET("movie/popular")
    suspend fun getPopularMovies(
        @Query("api_key") apiKey: String,
        @Query("language") language: String = "fr-FR",
        @Query("page") page: Int = 1,
        @Query("region") region: String = "FR"
    ): MovieResponseDto

    // Films français (avec with_original_language=fr)
    @GET("discover/movie")
    suspend fun getFrenchMovies(
        @Query("api_key") apiKey: String,
        @Query("language") language: String = "fr-FR",
        @Query("with_original_language") originalLanguage: String = "fr",
        @Query("sort_by") sortBy: String = "popularity.desc",
        @Query("page") page: Int = 1,
        @Query("region") region: String = "FR"
    ): MovieResponseDto

    // Films africains (plusieurs langues : ar, sw, yo, zu, am, etc. + pays africains)
    // On utilise with_origin_country pour les principaux pays
    @GET("discover/movie")
    suspend fun getAfricanMovies(
        @Query("api_key") apiKey: String,
        @Query("language") language: String = "fr-FR",
        @Query("with_origin_country") originCountry: String = "NG|ZA|SN|CI|CM|MA|TN|EG|KE|GH",
        @Query("sort_by") sortBy: String = "popularity.desc",
        @Query("page") page: Int = 1
    ): MovieResponseDto

    // Films en VF / VOSTFR (films non-français mais avec langue d'affichage fr)
    // Approximation : films populaires hors français
    @GET("discover/movie")
    suspend fun getVfMovies(
        @Query("api_key") apiKey: String,
        @Query("language") language: String = "fr-FR",
        @Query("without_original_language") withoutLanguage: String = "fr",
        @Query("sort_by") sortBy: String = "popularity.desc",
        @Query("page") page: Int = 1,
        @Query("region") region: String = "FR"
    ): MovieResponseDto

    // Recherche
    @GET("search/movie")
    suspend fun searchMovies(
        @Query("api_key") apiKey: String,
        @Query("query") query: String,
        @Query("language") language: String = "fr-FR",
        @Query("page") page: Int = 1,
        @Query("include_adult") includeAdult: Boolean = false
    ): MovieResponseDto

    // Détail d'un film
    @GET("movie/{movie_id}")
    suspend fun getMovieDetail(
        @Path("movie_id") movieId: Int,
        @Query("api_key") apiKey: String,
        @Query("language") language: String = "fr-FR",
        @Query("append_to_response") append: String = "credits,videos,watch/providers"
    ): MovieDetailDto
}
