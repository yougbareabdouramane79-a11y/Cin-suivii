package com.cinesuivi.util

object Constants {
    // Remplacez par votre clé API TMDB (gratuite sur https://www.themoviedb.org/settings/api)
    const val TMDB_API_KEY = "VOTRE_CLE_TMDB_ICI"
    const val TMDB_BASE_URL = "https://api.themoviedb.org/3/"
    const val TMDB_IMAGE_BASE_URL = "https://image.tmdb.org/t/p/"

    // Tailles d'images
    const val POSTER_SIZE_SMALL = "w185"
    const val POSTER_SIZE_MEDIUM = "w342"
    const val POSTER_SIZE_LARGE = "w500"
    const val BACKDROP_SIZE = "w780"
}
