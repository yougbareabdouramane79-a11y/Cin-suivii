package com.cinesuivi.data.remote.repository

import com.cinesuivi.data.model.Movie
import com.cinesuivi.data.model.MovieDetail
import com.cinesuivi.data.remote.api.TmdbApi
import com.cinesuivi.domain.repository.MovieRepository
import com.cinesuivi.util.Constants
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MovieRepositoryImpl @Inject constructor(
    private val api: TmdbApi
) : MovieRepository {

    override suspend fun getFrenchMovies(page: Int): Result<List<Movie>> {
        return try {
            val response = api.getFrenchMovies(
                apiKey = Constants.TMDB_API_KEY,
                page = page
            )
            Result.success(response.results.map { it.toDomain() })
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getAfricanMovies(page: Int): Result<List<Movie>> {
        return try {
            val response = api.getAfricanMovies(
                apiKey = Constants.TMDB_API_KEY,
                page = page
            )
            Result.success(response.results.map { it.toDomain() })
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getVfMovies(page: Int): Result<List<Movie>> {
        return try {
            val response = api.getVfMovies(
                apiKey = Constants.TMDB_API_KEY,
                page = page
            )
            Result.success(response.results.map { it.toDomain() })
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun searchMovies(query: String, page: Int): Result<List<Movie>> {
        return try {
            val response = api.searchMovies(
                apiKey = Constants.TMDB_API_KEY,
                query = query,
                page = page
            )
            Result.success(response.results.map { it.toDomain() })
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getMovieDetail(movieId: Int): Result<MovieDetail> {
        return try {
            val response = api.getMovieDetail(
                movieId = movieId,
                apiKey = Constants.TMDB_API_KEY
            )
            Result.success(response.toDomain())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getPopularMovies(page: Int): Result<List<Movie>> {
        return try {
            val response = api.getPopularMovies(
                apiKey = Constants.TMDB_API_KEY,
                page = page
            )
            Result.success(response.results.map { it.toDomain() })
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
