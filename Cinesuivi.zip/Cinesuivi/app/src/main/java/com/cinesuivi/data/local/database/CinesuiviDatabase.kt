package com.cinesuivi.data.local.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.cinesuivi.data.local.database.dao.UserMovieDao
import com.cinesuivi.data.local.database.entities.UserMovieEntity

@Database(
    entities = [UserMovieEntity::class],
    version = 1,
    exportSchema = false
)
abstract class CinesuiviDatabase : RoomDatabase() {
    abstract fun userMovieDao(): UserMovieDao
}
