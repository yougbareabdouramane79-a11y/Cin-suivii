package com.cinesuivi.data.local.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.cinesuivi.data.local.database.entities.UserMovieEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserMovieDao {

    @Query("SELECT * FROM user_movies WHERE isToWatch = 1 ORDER BY updatedAt DESC")
    fun getToWatch(): Flow<List<UserMovieEntity>>

    @Query("SELECT * FROM user_movies WHERE isWatched = 1 ORDER BY updatedAt DESC")
    fun getWatched(): Flow<List<UserMovieEntity>>

    @Query("SELECT * FROM user_movies WHERE isFavorite = 1 ORDER BY updatedAt DESC")
    fun getFavorites(): Flow<List<UserMovieEntity>>

    @Query("SELECT * FROM user_movies WHERE movieId = :movieId LIMIT 1")
    suspend fun getById(movieId: Int): UserMovieEntity?

    @Query("SELECT * FROM user_movies WHERE movieId = :movieId LIMIT 1")
    fun observeById(movieId: Int): Flow<UserMovieEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(movie: UserMovieEntity)

    @Update
    suspend fun update(movie: UserMovieEntity)

    @Query("DELETE FROM user_movies WHERE movieId = :movieId")
    suspend fun delete(movieId: Int)
}
