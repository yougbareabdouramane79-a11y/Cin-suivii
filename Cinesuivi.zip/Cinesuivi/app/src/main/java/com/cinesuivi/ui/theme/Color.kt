package com.cinesuivi.ui.theme

import androidx.compose.ui.graphics.Color

// Couleurs principales inspirées de Netflix mais adaptées
val RedPrimary = Color(0xFFE50914)
val RedDark = Color(0xFFB20710)
val RedLight = Color(0xFFFF4D4D)

val BackgroundDark = Color(0xFF141414)
val SurfaceDark = Color(0xFF1F1F1F)
val SurfaceVariantDark = Color(0xFF2A2A2A)

val BackgroundLight = Color(0xFFFFFFFF)
val SurfaceLight = Color(0xFFF5F5F5)
val SurfaceVariantLight = Color(0xFFEEEEEE)

val TextPrimaryDark = Color(0xFFFFFFFF)
val TextSecondaryDark = Color(0xFFB3B3B3)
val TextPrimaryLight = Color(0xFF141414)
val TextSecondaryLight = Color(0xFF564D4D)

val AccentGold = Color(0xFFFFD700)
val SuccessGreen = Color(0xFF46D369)
