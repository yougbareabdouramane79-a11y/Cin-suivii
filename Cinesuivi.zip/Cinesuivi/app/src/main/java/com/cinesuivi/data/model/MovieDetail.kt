package com.cinesuivi.data.model

data class MovieDetail(
    val id: Int,
    val title: String,
    val originalTitle: String? = null,
    val overview: String? = null,
    val posterPath: String? = null,
    val backdropPath: String? = null,
    val releaseDate: String? = null,
    val runtime: Int? = null,
    val voteAverage: Double = 0.0,
    val voteCount: Int = 0,
    val genres: List<Genre> = emptyList(),
    val originalLanguage: String? = null,
    val status: String? = null,
    val tagline: String? = null,
    val budget: Long = 0,
    val revenue: Long = 0,
    val adult: Boolean = false
) {
    fun posterUrl(size: String = "w500"): String? {
        return posterPath?.let { "https://image.tmdb.org/t/p/$size$it" }
    }

    fun backdropUrl(size: String = "w780"): String? {
        return backdropPath?.let { "https://image.tmdb.org/t/p/$size$it" }
    }

    val year: String
        get() = releaseDate?.take(4) ?: ""

    val runtimeFormatted: String
        get() = runtime?.let {
            val hours = it / 60
            val minutes = it % 60
            if (hours > 0) "${hours}h${minutes.toString().padStart(2, '0')}" else "${minutes}min"
        } ?: ""
}

data class Genre(
    val id: Int,
    val name: String
)
