package com.cinesuivi.data.local.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_movies")
data class UserMovieEntity(
    @PrimaryKey val movieId: Int,
    val title: String,
    val posterPath: String?,
    val releaseDate: String?,
    val voteAverage: Double,
    val isToWatch: Boolean = false,
    val isWatched: Boolean = false,
    val isFavorite: Boolean = false,
    val userRating: Float? = null,
    val userReview: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)
