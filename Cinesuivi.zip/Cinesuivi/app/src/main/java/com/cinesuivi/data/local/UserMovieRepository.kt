package com.cinesuivi.data.local

import com.cinesuivi.data.local.database.dao.UserMovieDao
import com.cinesuivi.data.local.database.entities.UserMovieEntity
import com.cinesuivi.data.model.Movie
import com.cinesuivi.data.model.MovieDetail
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserMovieRepository @Inject constructor(
    private val dao: UserMovieDao
) {
    fun getToWatch(): Flow<List<UserMovieEntity>> = dao.getToWatch()
    fun getWatched(): Flow<List<UserMovieEntity>> = dao.getWatched()
    fun getFavorites(): Flow<List<UserMovieEntity>> = dao.getFavorites()
    fun observeMovie(movieId: Int): Flow<UserMovieEntity?> = dao.observeById(movieId)

    suspend fun toggleToWatch(movie: MovieDetail) {
        val existing = dao.getById(movie.id)
        if (existing != null) {
            dao.update(existing.copy(isToWatch = !existing.isToWatch, updatedAt = System.currentTimeMillis()))
        } else {
            dao.insert(
                UserMovieEntity(
                    movieId = movie.id,
                    title = movie.title,
                    posterPath = movie.posterPath,
                    releaseDate = movie.releaseDate,
                    voteAverage = movie.voteAverage,
                    isToWatch = true
                )
            )
        }
    }

    suspend fun toggleWatched(movie: MovieDetail) {
        val existing = dao.getById(movie.id)
        if (existing != null) {
            dao.update(existing.copy(isWatched = !existing.isWatched, updatedAt = System.currentTimeMillis()))
        } else {
            dao.insert(
                UserMovieEntity(
                    movieId = movie.id,
                    title = movie.title,
                    posterPath = movie.posterPath,
                    releaseDate = movie.releaseDate,
                    voteAverage = movie.voteAverage,
                    isWatched = true
                )
            )
        }
    }

    suspend fun toggleFavorite(movie: MovieDetail) {
        val existing = dao.getById(movie.id)
        if (existing != null) {
            dao.update(existing.copy(isFavorite = !existing.isFavorite, updatedAt = System.currentTimeMillis()))
        } else {
            dao.insert(
                UserMovieEntity(
                    movieId = movie.id,
                    title = movie.title,
                    posterPath = movie.posterPath,
                    releaseDate = movie.releaseDate,
                    voteAverage = movie.voteAverage,
                    isFavorite = true
                )
            )
        }
    }

    suspend fun setRating(movieId: Int, rating: Float, review: String? = null) {
        val existing = dao.getById(movieId) ?: return
        dao.update(existing.copy(userRating = rating, userReview = review, updatedAt = System.currentTimeMillis()))
    }

    // Helper from Movie (for lists display)
    fun toMovie(entity: UserMovieEntity): Movie = Movie(
        id = entity.movieId,
        title = entity.title,
        posterPath = entity.posterPath,
        releaseDate = entity.releaseDate,
        voteAverage = entity.voteAverage
    )
}
