package com.cinesuivi.di

import android.content.Context
import androidx.room.Room
import com.cinesuivi.data.local.database.CinesuiviDatabase
import com.cinesuivi.data.local.database.dao.UserMovieDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): CinesuiviDatabase {
        return Room.databaseBuilder(
            context,
            CinesuiviDatabase::class.java,
            "cinesuivi.db"
        ).build()
    }

    @Provides
    @Singleton
    fun provideUserMovieDao(database: CinesuiviDatabase): UserMovieDao {
        return database.userMovieDao()
    }
}
